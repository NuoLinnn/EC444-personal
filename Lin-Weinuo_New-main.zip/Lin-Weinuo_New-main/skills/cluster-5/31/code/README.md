# Code Readme

This code contains the .c file for sending and receieving data using IR. 