# Skill 31: TX-IR

# Summary:
In this skill, an IR sensor was used to send data from one ESP to to another. Eric's ESP was set as the sender and my ESP was set as the receiver. Eric's ESP sends the data needed to cycle through a cycle of LEDs (red -> green -> Blue -> off). The data is sent using the IR LED and the data is received using the IR receiver. The receiver ESP then parses through the data packet sent and updates the LED being turned on accordingly (with a slight delay).

# Evidence:
![Alt text](image.png)
Caption: physical circuit built

Video Link:https://drive.google.com/file/d/1LBTEiHFTyvLi-VfKwVeT32KOsXpfmAIv/view?usp=sharing