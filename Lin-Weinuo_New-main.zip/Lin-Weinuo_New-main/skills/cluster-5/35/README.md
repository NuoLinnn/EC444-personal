# Skill 35: FSM

# Summary:
In this skill, a finite State Machine that modeled a whack-a-mole game was created and implemented in C. This was done by using a switch statement and transitions to transition between each state. Between states, actions can be made such as incrementing the score value. In this implementation, the game ends when the timer reaches 30 seconds and the player has 2 seconds to hit the mole when they appear. They "whack" the mole by pressing the 1, 2, 3 number keys. The final score is given at the end of the game. 

![image](https://github.com/BU-EC444/Lin-Weinuo_New/assets/144183166/2ad2c436-6667-4a2c-a36e-e39da44cedd3)
Caption: FSM of game

![image](https://github.com/BU-EC444/Lin-Weinuo_New/assets/144183166/af6bb8f0-8ead-4a0c-ad89-91fcfc07b2bd)
Caption: State Table

![image](https://github.com/BU-EC444/Lin-Weinuo_New/assets/144183166/b6efe3a0-b2b2-4c7b-a688-a9fd537853b1)
Caption: Terminal Output of Game


