# Code Readme

This code readME contains the .c file for the whack a mole game.
