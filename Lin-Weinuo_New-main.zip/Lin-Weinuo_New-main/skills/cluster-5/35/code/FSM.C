#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <windows.h> // For sleep function


#define IDLE 0
#define MOLE1_UP 1
#define MOLE2_UP 2
#define MOLE3_UP 3
#define WHACKED 4
#define GAME_OVER 5
#define GAME_START 6

int state = IDLE;
int score = 0;
int timeRemaining = 30; // Set the initial time in seconds
int whackTimer = 2;
bool missed = 0;
bool clock = 0; // timer counts down if clock is true

int whackMoleNum = 0;

void WhackAMoleGame() {
    char buffer[256];  // Buffer for input

    while (1) {
        char buffer[256];  // Buffer for input
        switch (state) {
            case IDLE:
                score = 0;
                timeRemaining = 10;
                clock = 0;
                printf("press 1 to start game! \n");
                fgets(buffer, sizeof(buffer), stdin);
                sscanf(buffer, "%d", &whackMoleNum);

                if (whackMoleNum == 1) {
                    printf("game Start! \n");
                    clock = 1;
                    state = GAME_START;
                }
                break;
            case GAME_START:
                clock = 1;
                int random = rand() % 4;
                if (clock == 1) {
                    if (random == 1) {
                        state = MOLE1_UP;
                        whackTimer = 2;
                        printf ("moles state: 001 \n");
                        }
                    if (random == 2) {
                        state = MOLE2_UP;
                        whackTimer = 2;
                        printf ("moles state: 010 \n");
                        }
                    if (random == 3) {
                        state = MOLE3_UP;
                        whackTimer = 2;
                        printf ("moles state: 100 \n");
                        }
                }
                else if (!clock){
                    state = GAME_OVER;
                }
                break;
            case MOLE1_UP:
                fgets(buffer, sizeof(buffer), stdin);
                sscanf(buffer, "%d", &whackMoleNum);
                if (missed == 1) {
                    state = GAME_START;
                    whackTimer = 2;
                    missed = 0;
                    printf("missed reset \n");
                }
                else if (whackMoleNum == 1 && clock == 1) {
                    printf("mole whacked! \n");
                    state = WHACKED;
                    score++;
                }
                else if (!clock){
                    state = GAME_OVER;
                }
                break;

            case MOLE2_UP:
                fgets(buffer, sizeof(buffer), stdin);
                sscanf(buffer, "%d", &whackMoleNum);

                if (missed) {
                    state = GAME_START;
                    whackTimer = 2;
                    missed = 0;
                }
                else if (whackMoleNum == 2 && clock == 1) {
                    printf("mole whacked! \n");
                    state = WHACKED;
                    score++;
                }
                else if (!clock){
                    state = GAME_OVER;
                }
                break;

            case MOLE3_UP:
                fgets(buffer, sizeof(buffer), stdin);
                sscanf(buffer, "%d", &whackMoleNum);

                if (missed) {
                    state = GAME_START;
                    whackTimer = 2;
                    missed = 0;
                }
                else if (whackMoleNum == 3 && clock == 1) {
                    printf("mole whacked! \n");
                    state = WHACKED;
                    score++;
                }
                else if (!clock){
                    state = GAME_OVER;
                }
                break;

            case WHACKED:
                // Transition to IDLE after whacking a mole
                state = GAME_START;
                whackTimer = 2;
                break;

            case GAME_OVER:
                // Handle GAME_OVER state if needed
                printf("Game Over! Your Score: %d\n", score);
                state = IDLE;
                break;
        }

    }
}

void timer() {
    while (1) {
        if (clock == 1) {
            Sleep(1000); // Sleep for 1 second
            timeRemaining--;
            whackTimer--;

            if (timeRemaining == 5) {
                printf(" \n5 seconds left! \n" );
            }

            if (timeRemaining == 0) {
                printf("\n GAMEOVER, Score: %d", score);
                clock = 0;
            }

            if (whackTimer == 0) {
                printf("MISSED BRUH >=( \n");
                whackTimer = 2;
                missed = 1;
            }
        }
    }
    
}

int main() {
    // Create two threads for WhackAMoleGame and timer functions
    HANDLE hThread1 = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)WhackAMoleGame, NULL, 0, NULL);
    HANDLE hThread2 = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)timer, NULL, 0, NULL);

    WaitForSingleObject(hThread1, INFINITE);
    WaitForSingleObject(hThread2, INFINITE);

    CloseHandle(hThread1);
    CloseHandle(hThread2);
    return 0;
}
