# Code folder ReadMe

This code folder contains two subfolders, one for displaying text onto the OLED and another one for displaying a QR code. 