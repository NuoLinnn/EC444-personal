# Skill 33: OLED Display

# Summary

In this skill, an OLED display was wired up as an I2C device and two different images were displayed onto it. The first one displays the name of our team "Team Squigglies!". The second one displays a custom QR code, which is a link to "Tetr.io". This was done by converting to QR code to a bitmap and formatted to fit within the dimensions of the OLED display.

# photos
![Alt text](image-1.png)
Caption: Custom Text for Team Squigglies!

![Alt text](image.png)
Caption: QR code for Tetr.io