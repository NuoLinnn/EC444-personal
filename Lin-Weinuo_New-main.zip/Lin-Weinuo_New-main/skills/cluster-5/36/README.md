# SKill 36: Security Issues

# Summary:

System Overview:

![Alt text](image.png)

Users employ internet-capable devices for car/robot control via WiFi and HTTP.
User commands reach the server, which acts as an intermediary to relay instructions to the car/robot.
Microcontrollers manage the car/robot operations, with features like timers, speedometers, and sensor data.
Sensor data is sent back to the user, necessitating continuous internet access for seamless communication.
Security Weaknesses:

Client:
Malware on user devices can compromise car/robot control.
Weak client device security exposes control access to potential attackers.
Local Network:
Weak WiFi security permits unauthorized access and potential data interception.
Internet:
Poorly encrypted data can be intercepted during transmission.
Denial of Service (DoS) attacks may overwhelm the server, disrupting communication.
Server:
Weak server security may lead to unauthorized access and intercepted communication.
Node.js:
Security vulnerabilities in external libraries or code injection can compromise the entire server.
ESP32:
Firmware weaknesses may lead to unauthorized access, and hardware manipulation can exploit vulnerabilities.
Potential Attacks:

Phishing Attack:
Attackers trick users into revealing sensitive information, using it to access car/robot controls via a fake application.
Network Attack:
Unauthorized access to WiFi allows interception and alteration of control information transmitted to the car/robot.
Server Attack:
Exploiting server vulnerabilities enables unauthorized access, potentially manipulating information for both user and car/robot.
Hardware Attack:
Attackers replace the ESP32, gaining direct control over the car/robot by bypassing software security measures.
Firmware Attack:
Exploiting firmware weaknesses allows unauthorized access and control over the car/robot.
Mitigation Strategies:

Phishing Attack:
Implement Two-Factor Authentication for enhanced user protection.
Network Attack:
Ensure encryption of sensitive information during transmission and maintain updated WiFi security protocols.
Server Attack:
Conduct regular server tests, fix identified flaws promptly, and deploy detection systems to alert against attacks.
Hardware Attack:
Physically secure the car/robot, implement seals for unauthorized access detection, and authorize hardware components.
Firmware Attack:
Regularly verify and update firmware authenticity, employ alert systems, and continuously monitor for unusual behavior.




