import time
from picamera2 import Picamera2
from pyzbar import pyzbar
import numpy as np
def find_qr_code(image):
    """Detect QR codes in the given image."""
    decoded_objects = pyzbar.decode(image)
    return decoded_objects
def capture_image_when_qr_detected(picam2):
    while True:
        # Capture an image to memory (numpy array)
        image = picam2.capture_array()
        qr_codes = find_qr_code(image)
        if qr_codes:
            # QR code detected
            for qr_code in qr_codes:
                url = qr_code.data.decode("utf-8")    
                print("QR Code detected, URL:", url)
            metadata = picam2.capture_file("QR.jpg")
            print("Image saved.")
            print(metadata)
            break
        else:
            print("No QR code detected. Trying again...")
        time.sleep(2)  
picam2 = Picamera2()

capture_config = picam2.create_still_configuration(main={"size": (800, 600)})
picam2.configure(capture_config)
picam2.start()
try:
    capture_image_when_qr_detected(picam2)
finally:
    picam2.close()