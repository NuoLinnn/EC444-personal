# Code Readme

# Summary:
In this skill, we've set up a pi with a camera to scan a QR code and print out the URL of the QR code. This was done by periodically scanning each image of the pi camera for an image and if a QR code is found, the URL would be displayed. 

# Video:
https://drive.google.com/file/d/19VX1xygoEZiI8aJPEMcRI1iEjrAU5GSY/view?usp=sharing