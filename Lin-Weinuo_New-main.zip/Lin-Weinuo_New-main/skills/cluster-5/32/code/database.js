//Weinuo Lin

const Db = require('tingodb')().Db;
const assert = require('assert');

const db = new Db('./Database', {});
const sensorData = db.collection('sensorData');

// sensor Data
const Data = [
    { Time: 1000, ID: 1, Smoke: 0, Temp: 30.99551665 },
    { Time: 1000, ID: 2, Smoke: 0, Temp: 32.61403901 },
    { Time: 1000, ID: 3, Smoke: 0, Temp: 34.24155482 },
    { Time: 1000, ID: 4, Smoke: 0, Temp: 33.93040826 },
    { Time: 1000, ID: 5, Smoke: 0, Temp: 32.16053975 },
    { Time: 2000, ID: 1, Smoke: 1, Temp: 39.84993413 },
    { Time: 2000, ID: 2, Smoke: 1, Temp: 39.15895748 },
    { Time: 2000, ID: 3, Smoke: 1, Temp: 35.31320566 },
    { Time: 2000, ID: 4, Smoke: 0, Temp: 32.11712677 },
    { Time: 2000, ID: 5, Smoke: 1, Temp: 37.6473977 },
    { Time: 3000, ID: 1, Smoke: 0, Temp: 31.79126176 },
    { Time: 3000, ID: 2, Smoke: 0, Temp: 34.59167108 },
    { Time: 3000, ID: 3, Smoke: 1, Temp: 39.74621965 },
    { Time: 3000, ID: 4, Smoke: 0, Temp: 32.78243087 },
    { Time: 3000, ID: 5, Smoke: 0, Temp: 32.1985166 },
    { Time: 4000, ID: 1, Smoke: 1, Temp: 38.92508781 },
    { Time: 4000, ID: 2, Smoke: 1, Temp: 38.37565977 },
    { Time: 4000, ID: 3, Smoke: 1, Temp: 36.13967757 },
    { Time: 4000, ID: 4, Smoke: 0, Temp: 30.65310732 },
    { Time: 4000, ID: 5, Smoke: 1, Temp: 36.15634141 },
    { Time: 5000, ID: 1, Smoke: 0, Temp: 33.23812762 },
    { Time: 5000, ID: 2, Smoke: 1, Temp: 38.79421257 },
    { Time: 5000, ID: 3, Smoke: 0, Temp: 32.52665853 },
    { Time: 5000, ID: 4, Smoke: 0, Temp: 32.51121025 },
    { Time: 5000, ID: 5, Smoke: 1, Temp: 36.72009154 },
    { Time: 6000, ID: 1, Smoke: 0, Temp: 32.05246 },
    { Time: 6000, ID: 2, Smoke: 0, Temp: 30.20902714 },
    { Time: 6000, ID: 3, Smoke: 0, Temp: 30.72132803 },
    { Time: 6000, ID: 4, Smoke: 0, Temp: 32.74850913 },
    { Time: 6000, ID: 5, Smoke: 1, Temp: 37.99525648 },
    { Time: 7000, ID: 1, Smoke: 0, Temp: 32.43955357 },
    { Time: 7000, ID: 2, Smoke: 0, Temp: 30.80847236 },
    { Time: 7000, ID: 3, Smoke: 0, Temp: 35.55775796 },
    { Time: 7000, ID: 4, Smoke: 0, Temp: 32.59427507 },
    { Time: 7000, ID: 5, Smoke: 0, Temp: 33.09164948 },
    { Time: 8000, ID: 1, Smoke: 0, Temp: 32.53844413 },
    { Time: 8000, ID: 2, Smoke: 1, Temp: 35.42446473 },
    { Time: 8000, ID: 3, Smoke: 0, Temp: 33.32221928 },
    { Time: 8000, ID: 4, Smoke: 1, Temp: 39.43899699 },
    { Time: 8000, ID: 5, Smoke: 0, Temp: 30.02392797 },
];


// Insert sample data into the database
sensorData.insert(Data, { w: 1 }, function(err, result) {
    assert.equal(null, err);

    // Query the database for instances when sensor ID 1 has smoke
    var query = {
        ID: 1,
        Smoke: 1,
    };

    sensorData.find(query).toArray(function(err, items) {
        assert.equal(null, err);
        console.log('Query result:');
        console.log(items);
    });
});
