# SKill 32: Database

# Summary:

A sample dataset was queried to find instances where ID = 1 and smoke = 1. This was done using TingoDB, which is a lightweight SQL API. The data is also written to a new file using TingoDB. In essence, the sensor data set was read, written, and queried. 

# Screenshots
![Alt text](image.png)
caption: output from query
![Alt text](image-1.png)
Caption: written data 