# Skill 28: Lidar

In this skill, a Lidar sensor was setup to read the distance from the lidar to the nearest object in its line of sight. The code was adapted form the arduino code and converted to ESP32 C code. The lidar is used as an I2C device. 

# Photos and videos

Video link: https://drive.google.com/file/d/1YH2w9Yk0O55eMFn3_CpW3HyCEpvhLAlr/view?usp=drive_link

![Alt text](image.png)
Caption: physical circuit built