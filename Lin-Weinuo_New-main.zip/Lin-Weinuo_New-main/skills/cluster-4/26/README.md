# Skill 26: Buggy

In this skill, the buggy's servo motors were controlled using WASD controls on the keyboard. The steering servo and the esc servo were instantiated using PWM and when "W" or "s" is pressed, this would increase or decrease the PWM signal accordingly. A similar thing was done for the "A" and "D" keys, which turns the steering servo to change the direction of the front wheels. The reverse functionality is handled by the ESC, where you have to input "swss" to drive in reverse. 

# Video Demo
https://drive.google.com/file/d/1qPousszMlM6K1buKEEsSRS0NsW9hTskR/view?usp=drive_link