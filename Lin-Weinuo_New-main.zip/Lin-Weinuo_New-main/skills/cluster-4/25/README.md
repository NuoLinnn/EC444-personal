# Servos

# summary
In this skill, a servo was connected to the ESP-32 and controlled via PWM. The minimum and maximum pulse widths were set to 700 and 2300 microseconds respectively. A simple code was written to take in a user input angle, which would then change the angle on the servo motor.

# video and photos
![Alt text](image.png)
Caption: picture of ciruit connection, with the servo set to 45 degrees.


