# Code Readme

This code folder contains the servo.c file which takes in a user input angle of 90 to -90 degrees and forces the servo motor to change to that angle via PWM. 