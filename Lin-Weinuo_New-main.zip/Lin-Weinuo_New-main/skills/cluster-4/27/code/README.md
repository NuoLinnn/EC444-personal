# Code Readme

This code folder contains the code for the wheel speed encoder. 