# Skill 27: Wheel Speed

In this skill, an optical encoder was used to calculate the wheel speed of the buggy. First, an encoding graphic of alternating black and white slices of a circle was taped to the inside of the wheel. The encoder was then set up to point directly at the enconding graphic. On the software side, a pulse counter was used to calculate the number of times the encoder sees a change in the light level of the encoding graphic. A timer was then used to periodically calculate the pulse. With the the timer period set constant and the number of pulses obtained, we can then use the following equation to calculate the wheel ground speed: speed =  RPM X 60 (s/m) X wheel circumference (m).

# video demo:



https://drive.google.com/file/d/1-GouU9WXqfBaxcusWhFj0SVuWdSweyut/view?usp=drive_link  