## Skill : Photoresistor



# Summary:


![Alt text](image.png)