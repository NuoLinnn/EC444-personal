## Skill 7: Battery Voltage Monitor



# Summary:
I built a voltage divider that divides the 3.3V input by half, using two 1k Ohm resistors. the divided voltage is then captured by the ADC on the ESP32. With a default attenuation of 0, the output voltage was around 1V, but a voltage of 1.65V is expected. By changing the attenuation factor to 11 dB, the output voltage is 1.7V, which is closer to the expected value. 


![Alt text](image-2.png)
Caption: physical circuit built.

![Alt text](image-3.png)
Caption: Terminal output of ADC.