# Code Readme

This code measures the voltage of a circuit via a continuous ADC. The attenuation factor was changed to 11. 