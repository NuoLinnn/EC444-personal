// Weinuo Lin

// includes
#include <stdio.h>
#include <string.h>
#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_vfs_dev.h"	// This is associated with VFS -- virtual file system interface and abstraction -- see the docs
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"


// defines
#define LED 13

bool LEDswitch = 0;
int mode = 0;
static void configure_pins(void){
    gpio_reset_pin(LED);
    gpio_set_direction(LED, GPIO_MODE_OUTPUT);
}

static void toggleLED() {
  gpio_set_level(LED, LEDswitch);
  LEDswitch = !LEDswitch;
  printf("LED on / off \n");

}

static void changeMode() {
    mode = (mode % 3) + 1;
    if (mode == 1) {
      printf("Toggle LED Mode \n");
    }
    if (mode == 2) {
      printf("Echo Mode \n");
    }
    if (mode == 3) {
      printf("Enter An Integer \n");
    }
}

static void modes(char input) {
    switch (mode) {
        case 1:
            if (input == 't') {
              printf("Read: t \n");
                toggleLED();
            }
            break;

        case 2:
                // Echo input characters 
                //printf("Echo: ");
                if (input != 's'){
                  putchar(input);
                }

        case 3:
            static char decimalBuffer[10] = {0};
            static int bufferIndex = 0;

            if (input >= '0' && input <= '9') {
                // Append the input digit to a buffer
                decimalBuffer[bufferIndex++] = input;
            } else if (bufferIndex > 0) {
                // Convert the buffer to an integer and reset
                decimalBuffer[bufferIndex] = '\0'; // Null-terminate the string
                int decimalValue = atoi(decimalBuffer);

                // Check if the input is a positive decimal
                if (decimalValue > 0) {
                    printf("Decimal: %d Hex: 0x%x\n", decimalValue, decimalValue);
                }

                // Clear the buffer
                memset(decimalBuffer, 0, sizeof(decimalBuffer));
                bufferIndex = 0;
            }
            break;
    }

    if (input == 's') {
        changeMode();
    }
}


void app_main() {
    /* Install UART driver for interrupt-driven reads and writes */
    ESP_ERROR_CHECK(uart_driver_install(UART_NUM_0, 256, 0, 0, NULL, 0));

    /* Tell VFS to use UART driver */
    esp_vfs_dev_uart_use_driver(UART_NUM_0);

    configure_pins();
    char input;

    while (1) {
      if (scanf("%c", &input) == 1) {
        modes(input);
      }

      vTaskDelay(50 / portTICK_PERIOD_MS);
    }
}





