// Weinuo Lin

#include <stdio.h>
#include <string.h>
#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_vfs_dev.h"	// This is associated with VFS -- virtual file system interface and abstraction -- see the docs
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

// Define LED and button GPIO pins
#define LED1 13
#define LED2 12
#define LED3 27
#define LED4 33
#define button 15

static void configure_pins(void)
{
    gpio_reset_pin(LED1);
    gpio_reset_pin(LED2);
    gpio_reset_pin(LED3);
    gpio_reset_pin(LED4);
    gpio_reset_pin(button);

    gpio_set_direction(LED1, GPIO_MODE_OUTPUT);
    gpio_set_direction(LED2, GPIO_MODE_OUTPUT);
    gpio_set_direction(LED3, GPIO_MODE_OUTPUT);
    gpio_set_direction(LED4, GPIO_MODE_OUTPUT);
    gpio_set_direction(button, GPIO_MODE_INPUT);
}

int count = 0;
bool direction = false; // false is counting up, true is counting down

// task counts up either up or down depending on button press
static void task1(void){
    while (1) {
        if (direction == false) {
            if (count == 0) {   //LED for 0
                gpio_set_level(LED1, 0);
                gpio_set_level(LED2, 0);
                gpio_set_level(LED3, 0);
                vTaskDelay(1000/ portTICK_PERIOD_MS); // 1 second delay
                count++; // increase count by 1
            }
            else if (count == 1) {
                gpio_set_level(LED1, 1);
                gpio_set_level(LED2, 0);
                gpio_set_level(LED3, 0);
                count++; // increase count by 1
                vTaskDelay(1000/ portTICK_PERIOD_MS); // 1 second delay
            }
            else if (count == 2) {
                gpio_set_level(LED1, 0);
                gpio_set_level(LED2, 1);
                gpio_set_level(LED3, 0);
                count++; // increase count by 1
                vTaskDelay(1000/ portTICK_PERIOD_MS); // 1 second delay
            }
            else if (count == 3) {
                gpio_set_level(LED1, 1);
                gpio_set_level(LED2, 1);
                gpio_set_level(LED3, 0);
                count++; // increase count by 1
                vTaskDelay(1000/ portTICK_PERIOD_MS); // 1 second delay
            }
            else if (count == 4) {
                gpio_set_level(LED1, 0);
                gpio_set_level(LED2, 0);
                gpio_set_level(LED3, 1);
                count++; // increase count by 1
                vTaskDelay(1000/ portTICK_PERIOD_MS); // 1 second delay
            }
            else if (count == 5) {
                gpio_set_level(LED1, 1);
                gpio_set_level(LED2, 0);
                gpio_set_level(LED3, 1);
                count++; // increase count by 1
                vTaskDelay(1000/ portTICK_PERIOD_MS); // 1 second delay
            }
            else if (count == 6) {
                gpio_set_level(LED1, 0);
                gpio_set_level(LED2, 1);
                gpio_set_level(LED3, 1);
                count++; // increase count by 1
                vTaskDelay(1000/ portTICK_PERIOD_MS); // 1 second delay
            }
            else if (count == 7) {
                gpio_set_level(LED1, 1);
                gpio_set_level(LED2, 1);
                gpio_set_level(LED3, 1);
                count = 0; // increase count by 1
                vTaskDelay(1000/ portTICK_PERIOD_MS); // 1 second delay
            }
        }
        if (direction == true) {// direction is set to counting down 
            if (count == 7) {
                gpio_set_level(LED1, 1);
                gpio_set_level(LED2, 1);
                gpio_set_level(LED3, 1);
                count--; // decrease count by 1
                vTaskDelay(1000/ portTICK_PERIOD_MS); // 1 second delay
            }
            else if (count == 6) {
                gpio_set_level(LED1, 0);
                gpio_set_level(LED2, 1);
                gpio_set_level(LED3, 1);
                count--; // decrease count by 1
                vTaskDelay(1000/ portTICK_PERIOD_MS); // 1 second delay
            }
            else if (count == 5) {
                gpio_set_level(LED1, 1);
                gpio_set_level(LED2, 0);
                gpio_set_level(LED3, 1);
                count--; // decrease count by 1
                vTaskDelay(1000/ portTICK_PERIOD_MS); // 1 second delay
            }
            else if (count == 4) {
                gpio_set_level(LED1, 0);
                gpio_set_level(LED2, 0);
                gpio_set_level(LED3, 1);
                count--; // decrease count by 1
                vTaskDelay(1000/ portTICK_PERIOD_MS); // 1 second delay
            }
            else if (count == 3) {
                gpio_set_level(LED1, 1);
                gpio_set_level(LED2, 1);
                gpio_set_level(LED3, 0);
                count--; // decrease count by 1
                vTaskDelay(1000/ portTICK_PERIOD_MS); // 1 second delay
            }
            else if (count == 2) {
                gpio_set_level(LED1, 0);
                gpio_set_level(LED2, 1);
                gpio_set_level(LED3, 0);
                count--; // decrease count by 1
                vTaskDelay(1000/ portTICK_PERIOD_MS); // 1 second delay
            }
            else if (count == 1) {
                gpio_set_level(LED1, 1);
                gpio_set_level(LED2, 0);
                gpio_set_level(LED3, 0);
                count--; // decrease count by 1
                vTaskDelay(1000/ portTICK_PERIOD_MS); // 1 second delay
            }
            else if (count == 0) {
                gpio_set_level(LED1, 0);
                gpio_set_level(LED2, 0);
                gpio_set_level(LED3, 0);
                count = 7; // reset count to 7
                vTaskDelay(1000/ portTICK_PERIOD_MS); // 1 second delay
            }

        }   
    }
}

static void task2(void) {
    while (1) {
        if(gpio_get_level(button) == 1) {
            direction = !direction; // switch directions if button is pressed
            vTaskDelay(100 / portTICK_PERIOD_MS);
        }

        if (direction == 1) {
            gpio_set_level(LED4, 0); // blue LED lights up if binary 
        }
        else if (direction == 0) {
            gpio_set_level(LED4, 1);
        }
        vTaskDelay(100 / portTICK_PERIOD_MS);
    }
}
void app_main()
{
    configure_pins();
        
    xTaskCreate(task1, "task1",1024*2, NULL, 5, NULL);
    xTaskCreate(task2, "task2",1024*2, NULL, 5, NULL);
    
}