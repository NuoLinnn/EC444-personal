## Skill 8: The Thermistor



# Summary:


![Alt text](image.png)