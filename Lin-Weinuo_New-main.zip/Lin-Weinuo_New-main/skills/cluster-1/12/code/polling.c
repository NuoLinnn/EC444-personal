// Weinuo Lin

#include <stdio.h>
#include <string.h>
#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_vfs_dev.h"	// This is associated with VFS -- virtual file system interface and abstraction -- see the docs
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

// Define LED and button GPIO pins
#define LED1 13
#define LED2 12
#define LED3 27
#define LED4 33
#define button 15

static void configure_pins(void)
{
    // reset pins
    gpio_reset_pin(LED1);
    gpio_reset_pin(LED2);
    gpio_reset_pin(LED3);
    gpio_reset_pin(LED4);
    gpio_reset_pin(button);

    // set input and outputs for each pin
    gpio_set_direction(LED1, GPIO_MODE_OUTPUT);
    gpio_set_direction(LED2, GPIO_MODE_OUTPUT);
    gpio_set_direction(LED3, GPIO_MODE_OUTPUT);
    gpio_set_direction(LED4, GPIO_MODE_OUTPUT);
    gpio_set_direction(button, GPIO_MODE_INPUT);
}

int LEDCounter = 0;

static void lightUp(void) {
    
    // if button pressed, increase LED counter and polls every 0.5 seconds
    if (gpio_get_level(button) == 1) {
        LEDCounter++;
        printf("Button Pressed \n");
        vTaskDelay(50 / portTICK_PERIOD_MS);
        if (LEDCounter == 4){
            LEDCounter = 0;
        }
    else if (gpio_get_level(button) == 0) {
        printf("Button not pressed \n");
        vTaskDelay(50 / portTICK_PERIOD_MS);
    }
    }
    if (LEDCounter == 0){           // light up LED 1
        gpio_set_level(LED1, 1);
        gpio_set_level(LED2, 0);
        gpio_set_level(LED3, 0);
        gpio_set_level(LED4, 0);
        
    }
    if (LEDCounter == 1){           // light up LED 2
        gpio_set_level(LED1, 0);
        gpio_set_level(LED2, 1);
        gpio_set_level(LED3, 0);
        gpio_set_level(LED4, 0);
    }
    if (LEDCounter == 2){           // light up LED 3
        gpio_set_level(LED1, 0);
        gpio_set_level(LED2, 0);
        gpio_set_level(LED3, 1);
        gpio_set_level(LED4, 0);
    }
    if (LEDCounter == 3){           // light up LED 4
        gpio_set_level(LED1, 0);
        gpio_set_level(LED2, 0);
        gpio_set_level(LED3, 0);
        gpio_set_level(LED4, 1);
    }
}



void app_main()
{
    configure_pins();

    while (1) {
        lightUp();
        vTaskDelay(100/portTICK_PERIOD_MS);
    }
}