// Weinuo Lin

#include <stdio.h>
#include <string.h>
#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_vfs_dev.h"	// This is associated with VFS -- virtual file system interface and abstraction -- see the docs
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "sdkconfig.h"


// Define LED and button GPIO pins
#define LED1 13
#define LED2 12
#define LED3 27
#define LED4 33
#define button 15

// hardware interrput def
#define ESP_INTR_FLAG_DEFAULT 0
#define GPIO_INPUT_PIN_SEL 1ULL<<button 

int flag = 0;

//define button interrupt handler
static void IRAM_ATTR gpio_isr_handler(void* arg) {
    flag = 1;
}

static void configure_pins(void)
{
    // reset pins
    gpio_reset_pin(LED1);
    gpio_reset_pin(LED2);
    gpio_reset_pin(LED3);
    gpio_reset_pin(LED4);
    gpio_reset_pin(button);

    // set input and outputs for each pin
    gpio_set_direction(LED1, GPIO_MODE_OUTPUT);
    gpio_set_direction(LED2, GPIO_MODE_OUTPUT);
    gpio_set_direction(LED3, GPIO_MODE_OUTPUT);
    gpio_set_direction(LED4, GPIO_MODE_OUTPUT);
    gpio_set_direction(button, GPIO_MODE_INPUT);
}

// Intialize the GPIO to detect button press as interrupt
static void button_init() {
  gpio_config_t io_conf;
    io_conf.intr_type = GPIO_INTR_POSEDGE;     // interrupt of rising edge
    io_conf.pin_bit_mask = GPIO_INPUT_PIN_SEL; // bit mask of the pins, use GPIO4 here
    io_conf.mode = GPIO_MODE_INPUT;            // set as input mode
    io_conf.pull_up_en = 1;                    // enable resistor pull-up mode on pin
  gpio_config(&io_conf);                       // apply parameters
  gpio_intr_enable(button);          // enable interrupts on pin
  gpio_install_isr_service(ESP_INTR_FLAG_LEVEL3);   //install gpio isr service
  gpio_isr_handler_add(button, gpio_isr_handler, (void*) button); //hook isr handler for specific gpio pin
}



int LEDCounter = 0;

static void lightUp(void) {
    
    // if button pressed, increase LED counter and polls every 0.5 seconds
    if (gpio_get_level(button) == 1) {
        LEDCounter++;
        vTaskDelay(50 / portTICK_PERIOD_MS);
        if (LEDCounter == 4){
            LEDCounter = 0;
        }
    else if (gpio_get_level(button) == 0) {
        printf("Button not pressed \n");
        vTaskDelay(50 / portTICK_PERIOD_MS);
    }
    }
    if (LEDCounter == 0){           // light up LED 1
        gpio_set_level(LED1, 1);
        gpio_set_level(LED2, 0);
        gpio_set_level(LED3, 0);
        gpio_set_level(LED4, 0);
        
    }
    if (LEDCounter == 1){           // light up LED 2
        gpio_set_level(LED1, 0);
        gpio_set_level(LED2, 1);
        gpio_set_level(LED3, 0);
        gpio_set_level(LED4, 0);
    }
    if (LEDCounter == 2){           // light up LED 3
        gpio_set_level(LED1, 0);
        gpio_set_level(LED2, 0);
        gpio_set_level(LED3, 1);
        gpio_set_level(LED4, 0);
    }
    if (LEDCounter == 3){           // light up LED 4
        gpio_set_level(LED1, 0);
        gpio_set_level(LED2, 0);
        gpio_set_level(LED3, 0);
        gpio_set_level(LED4, 1);
    }
}



void app_main()
{
    configure_pins();
    button_init();
    printf("waiting for button press... \n");

    while (1) {
        if (flag) {
            printf("button pressed \n\n");
            flag = 0;
            lightUp();
            
        }
    vTaskDelay(100/portTICK_PERIOD_MS);
    }
}