# Skill 36: MQTT Quest

# Summary:

# Block Diagram
![Alt text](image.png)
caption: Block Diagram 

Summary:
For the block diagram, we have 3 ESP-32s each equipped with an accelerometer, a temperature sensor, and a multicolor LED to display the status of the seat. Green means that the seat (ESP-32) is not taken and RED means that the seat is reserved / taken. These ESPs will subscribe and publish to a message broker that is hosted on a Pi. It will publish information about the seat occupancy based on the temperature data and accelerometer data. This information is then published to an HTML for viewing on a website. The HTML is also used to publish seat reservations, which can be made on the website. This information is published to the broker, which then publishes the information to the ESPs to display the LEDs correctly. This HTML is connected to the router using DDNS so that it can be accessed from outside networks.

# Code Flowchart
![Alt text](image-1.png)
Caption: code flowchart 

Summary: 

# State Machine
![Alt text](image-2.png)
Caption: Finite State machine

Summary: The FSM represents the possible states that a seat could be in. When starting in the not occupied and not reserved state, reserving the seat will cause the state to transition to not occupied and reserved. From there if 5 minutes have elapsed (reservation expired), then the state will transition back to not occupied and not reserved state. From the unoccupied and reserved state, if heat is detected then it will transition to the occupied state. From the occupied state, if there is no heat then it will transition to unoccupied and unreserved. Also, from the unoccupied and unreserved state if heat is detected then it will transition to occupied.

