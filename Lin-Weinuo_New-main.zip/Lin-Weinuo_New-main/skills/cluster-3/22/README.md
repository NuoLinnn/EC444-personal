# Pi Camera

# summary
In this skill, the picamera was attached to the rasberrypi. The video was streamed using picamera2 library and displayed on VLC. This was done over the network. 

# video
https://drive.google.com/file/d/1of-EOZsjNhmFNKD03V384fyv59EdEdpr/view?usp=sharing
