# Skill 23: Node.js to Canvas.js and File

# Summary

In this skill, a circuit was built to obtain readings from a temperature sensor and photoresistor, which are connnected to an ADC on the ESP-32 (see image below for photo of circuit). The ESP was flashed with main.c to obtain readings from the sensors and output them using prinf. The socketio.js and socketio2.js files are then used to parse the data from the ESP-32 and report the current time.This data is then pushed to the html file using socket.IO. Finally, the index.html file graphs the data pushed from the node file and updates the graph everytime new data is passed in. Socketio2.js is different in that it also writes the data into a txt file. 

# photos and screenshots

![Alt text](image-1.png)
Caption: Physical circuit built.

![Alt text](image.png)
Caption: Graph of photoresistor and temperature sensor outputs plotted against the current time.

*** add screen shot of writing to csv/ txt file ***
