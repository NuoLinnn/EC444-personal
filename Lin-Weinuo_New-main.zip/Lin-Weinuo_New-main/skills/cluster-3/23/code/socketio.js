// Modules
const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');

const port = new SerialPort({ path: 'COM7', baudRate: 115200 });
const parser = port.pipe(new ReadlineParser({ delimiter: '\n' }));
const receivedData = [];

// Read the port data
port.on('open', () => {
    console.log('Serial port now open');
});

parser.on('data', (data) => {
    const currentTime = getCurrentTime();
    console.log(currentTime, data);
    const formatedData = `${data} ${currentTime}`;
    receivedData.push(formatedData);

    // Send data and time to the connected clients
    io.emit('serialData + time', formatedData);
});

// Serve the webpage
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

// User socket connection
io.on('connection', (socket) => {
    console.log('a user connected');

    socket.emit("Data from Serial" , receivedData);

    socket.on('disconnect', () => {
        console.log('user disconnected');
    });
});

// Listening on localhost:3000
http.listen(3000, () => {
    console.log('listening on *:3000');
});

function getCurrentTime() {
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const seconds = now.getSeconds().toString().padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
}
