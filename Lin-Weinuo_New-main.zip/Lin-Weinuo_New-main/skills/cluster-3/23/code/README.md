# Code Readme

This code folder contains main.c, which is flashed to the ESP-32, socketio.js, which processes the information from the ESP-32, and index.html, which graphs the results from socketio.js. socketio2.js is the same as socketio.js, except that it concurrently writes the data to a file using node. See the skill readME for more information on how this setup works. 