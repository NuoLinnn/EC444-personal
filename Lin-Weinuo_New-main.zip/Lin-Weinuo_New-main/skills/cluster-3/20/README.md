# Skill 20: ESP Wifi Station

# Summary
The ESP -32 was connected to the wifi using the station example code. This was then verified on the device list page. 

![Alt text](image.png)
Caption: 3rd device is the ESP 32 connected to the wifi network 