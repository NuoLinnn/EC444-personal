# Code README

The code folder contains the code needed to connect the ESP-32 to the wifi.