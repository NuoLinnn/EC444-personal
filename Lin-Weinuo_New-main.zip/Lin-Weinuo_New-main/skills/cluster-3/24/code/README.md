# Code Readme

This code folder contains 4 node.js files, 1 set for UDP server and client, skill24.js is another server element, and node.js is another client element. 