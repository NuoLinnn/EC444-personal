# Skill 24

# summary

In this skill, the node app was set up as a server on the laptop and the ESP32 was setup as the client. This was done by making the ESP32 send a request for the blink time, and the server responds with a new blink time. In the second part of this skill, the ESP was made into the server and the laptop was set up as the client. From this, a message was sent to the ESP32 to turn on the onboard LED.

# Photos and screenshots
https://drive.google.com/file/d/17QT5sCGmZQ_AD0rMwimjNZr38x5A0U_d/view?usp=drive_link
caption: video of working code