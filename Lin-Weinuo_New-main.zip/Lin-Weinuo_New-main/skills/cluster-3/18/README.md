# Skill 18: Router Config

# Summary
We reflashed the firmware and updated the settings according to the Ebook Repo (instructions).


![Alt text](image.png)
Caption: screenshot of some of the changes made.