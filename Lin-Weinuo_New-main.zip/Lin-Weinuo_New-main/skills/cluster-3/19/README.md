# Skill 20: Dynamic DNS

# Summary
The team created a server on port 8080 with node.js. Using a free DDNS service, an account was made. One of the member's laptops serves as the HTTP server. The domain name is http://squigglies.loseyourip.com. Using the node.js server, the server can be accessesd on any device regardless of network (even cellular). The node server port (8080) is added to the DDNS on the server side. The node server can then be accessed on other devices regardless of network using the external port (8081) and translating it to the internal port 8080. 

![Alt text](image.png)
Caption: accessing node.js server on external network

https://drive.google.com/file/d/10QBJS1QavlEghM_pDIAId2n_jj9_pkdC/view?usp=sharing
link to video of working DDNS

