# Code Readme

Please describe in this readme what is in your code folder and
subfolders. Make it easy for us to navigate this space.

Also
- Please provide your name and date in the comment header for any
code you submit
- Indicate within comment lines attributrion for any code you
have adopted from elsewhere
- Indicate, in code comments any use of AI for producing your code
