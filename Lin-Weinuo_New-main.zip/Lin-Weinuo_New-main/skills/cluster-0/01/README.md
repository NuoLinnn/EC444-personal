#  Skill 1: Install ESP32 IDF and Toolchain and Demonstrate ESP32 On-Board Blink

Author: Weinuo Lin

Date: 2023-9-9


### Summary
This skill demonstrates that I have successfully installed the appropriate drivers and toolchains for the ESP32. I have also successfully built and flashed "Blink" onto the Huzzah32 feather board with the serial output shown below. 

### Sketches/Diagrams
![Alt text](image.png)
screenshot of successful "blink" output
### Modules, Tools, Source Used Including Attribution


### Supporting Artifacts


