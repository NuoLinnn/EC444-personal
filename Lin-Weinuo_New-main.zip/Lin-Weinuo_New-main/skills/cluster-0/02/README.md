# Skill 2: Setup Editors and IDEs

The Editor has been set up and the IDE of choice is VS Code. See screenshot below for working IDE.

![Alt text](image.png)