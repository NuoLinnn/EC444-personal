# Skill 4:  Get Access to Piazza and Post Something

The Piazza post has been created per the assignment. 