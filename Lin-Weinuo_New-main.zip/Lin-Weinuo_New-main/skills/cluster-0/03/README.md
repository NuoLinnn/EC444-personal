#  03 - Setup and Use Github Individually

Author: Weinuo Lin

Date: 2023-9-8


### Summary
This skill demonstrates that I have successfully created a private GitHub repo on the BU-EC444 repo. 
This repo was then cloned onto my local machine, editted, pushed and commited to GitHub.


### Supporting Artifacts
- GitHub
- GitHub Desktop

