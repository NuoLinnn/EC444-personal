# Skill6: Create a New Project and Use GPIO to Control LEDs


# Skill 6 Code README

Name: Weinuo Lin
Date: 9/8/2023

The code makes a set of 3 LEDs count from 0 to 7 and then from 7 back down to 0 continuously.

See photo for working LEDs:
![Alt text](image.png)

See Video Link for working LEDs:
https://drive.google.com/file/d/1ji0qpEkVDLrPnMsO2U6yzXpf81nqHIcu/view?usp=drive_link