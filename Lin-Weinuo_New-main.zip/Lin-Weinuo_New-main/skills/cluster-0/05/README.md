# Skill 5: Uploading Video Cloud

Name: Weinuo Lin
Date: 9/8/2023

Content:
I have created the google drive and a short video intro. 
Video Link: https://drive.google.com/file/d/1r7bsOp0CAgaAV8wtdk3vi-jNO93hWs6z/view?usp=drive_link