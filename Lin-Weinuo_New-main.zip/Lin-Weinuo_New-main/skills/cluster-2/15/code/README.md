# Code Readme

This code folder contains the accelerometer code as well as the ADXL343 header to read the acceleration and calculates the pitch from the data. See skill README for more details. 