# Skill 15: Accelerometer

# Summary:
I built a circuit that connects the ESP-32 to an accelerometer, which measures the acceleration in the x y and z direction. This is then convereted to capture the pitch, yaw, and roll of the device and prints out the information onto the monitor. 



![Alt text](image-2.png)
Caption: physical circuit built

![Alt text](image.png)
Caption: static (stationary) acceleration value 

![Alt text](image-1.png)
Caption: acceleration and tilt values after subjecting accelerometer to random movements


