# Code Readme

This code folder contains the code for the timer. See the README to see how this code works. 
