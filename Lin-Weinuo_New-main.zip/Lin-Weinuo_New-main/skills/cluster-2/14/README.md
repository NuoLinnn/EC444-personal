# Skill 14: Timer

# Summary:
I built a circuit that connects the ESP-32 to a 14 segment LED display along side a button that acts as a switch. What the code does is that upon activiation of the button, the timer will start on the 14 segment LED display. The timer starts from 0s and counts up to 15s. Once the timer hits 15s, it will continue counting from 0s. If the user presses the button a second time, the timer will reset to 0 and stop the time. Pressing the button another time will restart the timer. 
For the code implementation, a button was first addressed as an interrupt, and a gptimer was initialized. When the button is first pressed, teh gptimer will begin count of the time. This count is then converted to the correct alphafont table and then displayed onto teh 14 segment LED display. Additional logic was added to loop the time from 15 to 0 seconds. 

![Alt text](image.png)
Caption: Photo of completed circuit

Video link to working code: https://drive.google.com/file/d/1MvV1jB_tlwOfq7J2qGI3uKFHxCpUCLEZ/view?usp=drive_link




