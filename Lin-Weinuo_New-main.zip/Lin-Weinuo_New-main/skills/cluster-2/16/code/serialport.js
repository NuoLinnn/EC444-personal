// Weinuo Lin

// Serial port example from design pattern
// Uses ESP code in folder: serial-esp-to-node-serialport

const {SerialPort} = require('serialport')
const port = new SerialPort({ path: 'COM7', baudRate: 115200 });

const fs = require('fs');
const {ReadlineParser} = require('@serialport/parser-readline');
const { time } = require('console');

const parser = port.pipe(new ReadlineParser({ delimiter: '\n' }));

// Read the port data
port.on("open", () => {
    console.log('Serial port now open');
    
    // Clear out all data from the data.csv file
    // this clearing of data from the data.csv file was created using chatGPT see read me for prompt
    fs.truncate("data.csv", 0, (err) => {
      if (err) {
        console.error(err);
      } else {
        console.log('Cleared data.csv');
      }
    });
  });
  

// get data from serialport, append to csv file
parser.on('data', data => {
    const currentTime = getCurrentTime();
    fs.writeFile("data.csv", `${data.trim()},${currentTime}\n`, { flag: 'a' }, (err) => {
      if (err) {
        console.error(err);
      } else {
        console.log(`${data.trim()}    ${currentTime}`);
      }
    });
  });

// get current hour, minute, second
function getCurrentTime() {
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const seconds = now.getSeconds().toString().padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
  }