# Code Readme

This code folder contains the serialport.js file that takes in the output from the ESP-32. 