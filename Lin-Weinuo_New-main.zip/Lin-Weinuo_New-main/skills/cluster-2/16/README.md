# Skill 16: Node.js

# Summary:
I built a circuit that connects the ESP-32 to a photocell. The output of the photocell is saved to a local csv file using node.js. The ESP is flashed with the corresponding code, but not monitored. I then wrote a node.js code that takes the output via the serialport and writes the data into a csv file. The time that the data was taken was also included in the dataset. 



![Alt text](image.png)
Caption: Photo of completed circuit

![Alt text](image-1.png)
Caption: CSV file after taking in readings

# AI usage:
The function that clears the csv file every time the node file is ran was created using ChatGPT. 
Prompt: given this code, make it so that the CVS file is cleared when the code is ran.

output: fs.truncate("data.csv", 0, (err) => {
      if (err) {
        console.error(err);
      } else {
        console.log('Cleared data.csv');
      }
    });


