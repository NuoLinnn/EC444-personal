# Code Readme

This code folder contains the code that controls the alphanumeric display. See skill read me to see how this code works.