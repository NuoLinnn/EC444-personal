# Skill 13: Alphanumeric Display

# Summary:
I built a circuit that connects the ESP-32 to a 14 segment LED display. The code works by taking in a user input of 8 characters or less and displays it on the LED display. This is done by converting the user input to ASCII, then to the alphanumeric font table, which dictates which LED segments should be turned on to create the proper LED display for that letter. 


![Alt text](image.png)
Caption: Physical circuit Built.

Video link of working program: https://drive.google.com/file/d/1z41g3chDs7zGMDW_QwK6qiYVZA_42mjW/view?usp=drive_link