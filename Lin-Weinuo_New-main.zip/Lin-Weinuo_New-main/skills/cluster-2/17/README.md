# Skill 17: CanvasJS

# Summary:
For this skill, I first looked at example graphs from CanvasJS. I then learned how to use HTML to create my own custom graph that displays the stock data. The data is stored in a CSV. 

![Alt text](image.png)
Caption: Example 1 from canvas.JS 

![Alt text](image-1.png)
Caption: Example 2 from canvas.JS

![Alt text](image-2.png)
Caption: stock data graph made using cavas.JS