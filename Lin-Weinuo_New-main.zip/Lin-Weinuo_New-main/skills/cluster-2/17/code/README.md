# Code Readme

This code folder contains the html code to create a graph of the stock closing prices of different companies. 